<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LabWeek extends Model
{
    //
}
