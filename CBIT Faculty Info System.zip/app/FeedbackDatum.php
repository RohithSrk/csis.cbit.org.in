<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FeedbackDatum extends Model
{
    //
}
