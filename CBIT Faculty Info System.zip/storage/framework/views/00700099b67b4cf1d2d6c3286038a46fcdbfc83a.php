<?php $__env->startSection('content'); ?>
    <div class="site-wrap login">
        <div id="reset-password-form">
            <div class="col-md-4" align="center">
                <div class="panel panel-default">
                    <div class="panel-header">
                        <div class="logo">
                            <h2>Reset Password</h2>
                        </div>
                    </div>

                    <form class="form-horizontal" method="POST" action="<?php echo e(route('password.request')); ?>">
                        <?php echo e(csrf_field()); ?>

                    <div class="panel-body">

                        <input type="hidden" name="token" value="<?php echo e($token); ?>">

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?> form-group-email">
                            <label for="email" class="col-md-4 hidden control-label">E-Mail Address</label>

                            <div class="">
                                <input id="email" type="email" placeholder="E-Mail Address" class="form-control" name="email" value="<?php echo e(isset($email) ? $email : old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?> form-group-password">
                            <label for="password" class="col-md-4 hidden control-label">Password</label>

                            <div class="">
                                <input id="password" type="password" placeholder="Password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?> form-group-password">
                            <label for="password-confirm" class="col-md-4 hidden control-label">Confirm Password</label>
                            <div class="">
                                <input id="password-confirm" placeholder="Confirm Password" type="password" class="form-control" name="password_confirmation" required>

                                <?php if($errors->has('password_confirmation')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer" align="right">
                        <input type="submit" class="btn btn-primary" value="Reset Password">
                    </div><!-- .panel-footer -->
                    </form>
                </div><!-- .panel -->
            </div><!-- .col-md-4 -->
        </div><!-- #reset-password-form -->
    </div><!-- .site-wrap -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>