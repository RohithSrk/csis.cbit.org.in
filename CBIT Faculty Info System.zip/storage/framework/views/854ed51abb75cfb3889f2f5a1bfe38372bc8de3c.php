<?php $__env->startSection( 'page-content' ); ?>
    <div class="page">
        <div class="page-main">

            <?php echo $__env->make('partials.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php if( ! empty( $feedback_arr ) ): ?>
            <div class="page-header">
                <h1 class="page-title ">Feedback Report</h1>
            </div><!-- .page-header -->

            <div class="page-content">

                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">Select Feedback</h4>
                            </div>
                            <?php echo e(Form::open(['action' => 'FeedbackController@viewReport', 'method' => 'post'])); ?>


                            <div class="panel-body admin-form">
                                <div class="col-md-4">
                                    <div class="section">
                                        <label for="select_feedback" class="field-label">Select Feedback</label>
                                        <label for="select_feedback" class="field">
                                            <?php echo e(Form::select('feedback', $feedback_arr, $feedback_id ?? '' , [
                                                'class' => 'form-control select',
                                                'id' => 'select_feedback' ])); ?>

                                        </label>
                                    </div><!-- section -->
                                </div><!-- col-md-4 -->

                                <div class="col-md-4">
                                    <div class="section">
                                        <label for="select_faculty" class="field-label">Select Faculty</label>
                                        <label for="select_faculty" class="field">
                                            <?php echo e(Form::select('faculty[]', $faculty_arr, $faculty_id ?? '' , [
                                                'class' => 'form-control select faculty-selector report',
                                                'id' => 'select_faculty',
                                                'multiple' => 'multiple' ])); ?>

                                        </label>
                                    </div><!-- section -->
                                </div><!-- col-md-4 -->

                            </div><!-- .panel-body -->

                            <div class="panel-footer admin-form" align="right">
                                <input type="submit" class="btn btn-sm btn-primary" value="Get Report">
                            </div>
                            <?php echo e(Form::close()); ?>

                        </div>
                    </div><!-- .col-lg-12 -->
                </div><!-- .row -->

                <?php if( ! empty( $criteria )): ?>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <?php echo e($feedback_arr[$feedback_id]); ?> Report.
                                    </h4>
                                </div>

                                <div class="panel-body marks-table">
                                    <div class="table-responsive">
                                        <table class="table table-bordered mb-0 th-bb-n" id="feedback-report">
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Faculty Name</th>
                                                <th>Subject</th>
                                                <th>Year/Section</th>
                                                <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <th title="<?php echo e($criterion->criterion); ?>"><?php echo e($criterion->code); ?></th>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <th>Percentage</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $feedback_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $feedback_datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="width-50"><?php echo e($i+1); ?></td>
                                                    <td ><?php echo e($employees_arr[ $feedback_datum['employee_id']]); ?></td>
                                                    <td ><?php echo e($subjects_arr[ $feedback_datum['subject_id']]); ?></td>
                                                    <td ><?php echo e(sectionGetYearSectionName( $feedback_datum['section_id'] )); ?></td>
                                                    <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td title="<?php echo e($criterion->criterion); ?>"><?php echo e(round(($feedback_datum[$criterion->code] / 4) * 100, 2)); ?></td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <td ><?php echo e(round($feedback_datum['percentage'], 2)); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div><!-- .table-responsive -->
                                </div>
                            </div>
                        </div><!-- .col-lg-12 -->
                    </div><!-- .row -->
                <?php endif; ?>

            </div><!-- .page-content -->
            <?php else: ?>
                <div class="alert alert-danger mg-top-15 text-left">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    No feedback available. Please create a new feedback by clicking <a href="<?php echo e(action('FeedbackController@create')); ?>">here</a>
                </div>
            <?php endif; ?>

        </div>
    </div><!-- .page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'layouts.master' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>