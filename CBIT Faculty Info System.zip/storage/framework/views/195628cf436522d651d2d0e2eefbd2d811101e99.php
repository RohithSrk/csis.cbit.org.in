<aside id="sidebar">

    <ul class="nav navigation">
        <li class="menu-item <?php echo e(empty( request()->segment(1) )? 'active' : ''); ?>">
            <a href="/"><i class="fa fa-home"></i><span class="menu-title">Home</span></a>
        </li>
        <li class="menu-item <?php echo e((request()->is('lab-marks/view')) ? 'active' : ''); ?>">
            <a href="<?php echo e(action('LabMarksController@studentIndexLabMarks')); ?>"><i class="fa fa-list-alt"></i><span
                        class="menu-title">View Lab Marks</span></a>
        </li>
        <li class="menu-item hidden">
            <a href="<?php echo e(URL::to('logout')); ?>"><i class="fa fa-sign-out"></i><span class="menu-title">Logout</span></a>
        </li>
        <li class="menu-item hidden">
            <a href="#"><i class="fa fa-info-circle"></i><span class="menu-title">About</span></a>
        </li>
        <li class="menu-item <?php echo e((request()->is('student/view-exam-marks')) ? 'active' : ''); ?>">
            <a href="<?php echo e(action('ExamMarksController@show')); ?>"><i class="fa fa-list"></i><span
                        class="menu-title">View Mid Marks</span></a>
        </li>
    </ul>

</aside><!-- #sidebar -->