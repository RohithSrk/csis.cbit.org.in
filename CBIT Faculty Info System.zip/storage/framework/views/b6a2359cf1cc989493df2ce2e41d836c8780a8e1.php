<?php $__env->startSection( 'page-content' ); ?>
    <div class="page">
        <div class="page-main">

            <?php echo $__env->make('partials.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php if( ! empty( $subjects ) ): ?>
                <div class="page-header">
                    <h1 class="page-title ">Weekly Lab Marks Entry</h1>
                </div>

                <!-- .page-header -->
                <div class="page-content">

                    <?php echo $__env->make('partials.select-students', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php if( ! empty( $students ) ): ?>

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">Student Lab Marks for <?php echo e($date); ?> ( <?php echo e($lab_weeks[ $lab_week_id ]); ?> )</h4>
                                    </div>
                                    <?php echo e(Form::open(array('action' => 'LabMarksController@store', 'method' => 'put'))); ?>

                                    <?php echo e(Form::hidden('date', $date)); ?>

                                    <?php echo e(Form::hidden('subject', $subject_id)); ?>

                                    <?php echo e(Form::hidden('batch', $batch_id)); ?>

                                    <?php echo e(Form::hidden('section', $section_id)); ?>

                                    <?php echo e(Form::hidden('labweek', $lab_week_id)); ?>


                                    <div class="panel-body marks-table">
                                        <div class="table-responsive">
                                            <table class="table table-bordered mb-0 th-bb-n">
                                                <thead>
                                                <tr>
                                                    <th>Roll Number</th>
                                                    <th>Name</th>
                                                    <?php $__currentLoopData = $mark_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <th><?php echo e($mark_type['name']); ?></th>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td class="width-150"><?php echo e($student->rollnum); ?></td>
                                                        <td><?php echo e($student->name); ?></td>

                                                        <?php 
                                                            $stdLabMarks = $student->getLabMarks( $subject_id, $date_formatted );
                                                         ?>

                                                        <?php $__currentLoopData = $mark_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <td class="width-100">
                                                                <?php echo e(Form::number( 'marks[' . $student->rollnum . '][' . $mark_type['name'] . ']'  ,
                                                                  (isset($stdLabMarks[ $mark_type['name'] ]))? $stdLabMarks[ $mark_type['name'] ] : '',
                                                                  array('min' => 0, 'max' => $mark_type['max_marks'], 'class' => 'form-control'))); ?>

                                                            </td>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div><!-- .table-responsive -->
                                    </div>
                                    <div class="panel-footer admin-form" align="right">
                                        <input type="submit" class="btn btn-sm btn-primary" value="Submit Marks">
                                    </div>
                                    <?php echo e(Form::close()); ?>

                                </div>
                            </div><!-- .col-lg-12 -->
                        </div><!-- .row -->
                    <?php endif; ?>

                </div><!-- .page-content -->
            <?php endif; ?>

        </div>
    </div><!-- .page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'layouts.master' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>