<?php $__env->startSection( 'page-content' ); ?>
    <div class="page">
        <div class="page-main">
            <div class="page-header">
                <h1 class="page-title ">Dashboard</h1>
            </div>

            <div class="page-content">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">My Courses</h4>
                            </div>

                            <div class="panel-body marks-table">
                                <div class="table-responsive">
                                    <table class="table table-bordered mb-0 th-bb-n">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Course Name</th>
                                            <th>Course Type</th>
                                        </tr>
                                        </thead>
                                        <tbody id="lab-mark-types">
                                        <?php $i = 0 ?>
                                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="width-50"><?php echo e(++$i); ?></td>
                                                <td><?php echo e($subject->name); ?></td>
                                                <td><?php echo e(ucwords($subject->type)); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if( empty( $subjects ) ): ?>
                                        <tr>
                                            <td colspan="4" align="center" class="alert alert-danger">No courses found!</td>
                                        </tr>
                                        <?php endif; ?>
                                        </tbody>
                                    </table><!-- .table-responsive -->
                                </div>
                            </div>
                        </div><!--.panel-->
                    </div>
                    <div class="col-lg-4">
                        <div id="dashboard-calendar"></div>
                    </div>
                </div><!-- .page-content -->
            </div>
        </div><!-- .page-main -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'layouts.master' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>