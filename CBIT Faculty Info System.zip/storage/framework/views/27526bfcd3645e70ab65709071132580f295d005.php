<?php $__env->startSection( 'page-content' ); ?>
    <div class="page">
        <div class="page-main">

            <?php echo $__env->make('partials.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php if( ! empty( $qp_arr ) ): ?>
                <div class="page-header">
                    <h1 class="page-title ">Add Mid Exam Marks</h1>
                </div>

                <!-- .page-header -->
                <div class="page-content">

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">Select Students & Exam</h4>
                                </div>
                                <form class="form-horizontal" action="/exam/add-marks" method="post">

                                    <?php echo e(csrf_field()); ?>


                                    <div class="panel-body admin-form">

                                        <div class="col-md-3">
                                            <div class="section">
                                                <label for="select_semester" class="field-label">Select Semester</label>
                                                <label for="select_semester" class="field">
                                                    <?php echo e(Form::select('semester', $semesters_arr, $semester_id ?? '' , [
                                                        'class' => 'form-control select',
                                                        'id' => 'select_semester' ])); ?>

                                                </label>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="section">
                                                <label for="select_section" class="field-label">Select Section</label>
                                                <label for="select_section" class="field">
                                                    <?php echo e(Form::select('section',$sections_arr, $section_id ?? '' , [
                                                        'class' => 'form-control select',
                                                        'id' => 'select_section' ])); ?>

                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="section">
                                                <label for="select_qp" class="field-label">Select Question Paper</label>
                                                <label for="select_qp" class="field">
                                                    <?php echo e(Form::select('question-paper', $qp_arr, $qp_id ?? '' , [
                                                        'class' => 'form-control select',
                                                        'id' => 'select_qp' ])); ?>

                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel-footer admin-form" align="right">
                                        <input type="submit" class="btn btn-sm btn-primary" value="Get Students">
                                    </div>
                                </form>
                            </div>
                        </div><!-- .col-lg-12 -->
                    </div><!-- .row -->

                    <?php if( ! empty( $students ) ): ?>

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">Student Exam Marks for ( <?php echo e($qp_arr[ $qp_id ]); ?> )</h4>
                                    </div>
                                    <?php echo e(Form::open(array('action' => 'ExamMarksController@store', 'method' => 'put'))); ?>

                                    <?php echo e(Form::hidden('question-paper', $qp_id)); ?>

                                    <?php echo e(Form::hidden('section', $section_id)); ?>

                                    <?php echo e(Form::hidden('semester', $semester_id)); ?>


                                    <div class="panel-body marks-table">
                                        <div class="table-responsive">
                                            <table class="table table-bordered mb-0 th-bb-n" id="student-lab-marks-entry">
                                                <thead>
                                                <tr>
                                                    <th>Roll Number</th>
                                                    <th>Name</th>
                                                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if( $question->subQuestions()->count() ): ?>
                                                            <?php $__currentLoopData = $question->subQuestions()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $squestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <th><?php echo e($squestion->question); ?></th>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php else: ?>
                                                            <th><?php echo e($question->question); ?></th>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $emarks = \App\ExamMark::getMarks( $student->id, $qp_id );
                                                        ?>
                                                        <tr>
                                                            <td class="width-100"><?php echo e($student->rollnum); ?></td>
                                                            <td><?php echo e(strtoupper($student->name)); ?></td>
                                                            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if( $question->subQuestions()->count() ): ?>
                                                                    <?php $__currentLoopData = $question->subQuestions()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $squestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <td style="width: 80px">
                                                                        <?php echo e(Form::number( 'emarks[' . $student->id . ']['. $question->id .'][' . $squestion->id . ']',
                                                                            $emarks[ $question->id ][ $squestion->id ],
                                                                          array('min' => 0, 'max' => $squestion->max_marks, 'class' => 'form-control', 'step' => 0.5))); ?>

                                                                        </td>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php else: ?>
                                                                    <td style="width: 80px">
                                                                        <?php echo e(Form::number( 'emarks[' . $student->id . '][' . $question->id . ']',
                                                                               $emarks[ $question->id ],
                                                                          array('min' => 0, 'max' => $question->max_marks, 'class' => 'form-control', 'step' => 0.5))); ?>

                                                                    </td>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div><!-- .table-responsive -->
                                    </div>
                                    <div class="panel-footer admin-form" align="right">
                                        <input type="submit" class="btn btn-sm btn-primary" value="Submit Marks">
                                    </div>
                                    <?php echo e(Form::close()); ?>

                                </div>
                            </div><!-- .col-lg-12 -->
                        </div><!-- .row -->
                    <?php endif; ?>

                </div><!-- .page-content -->
            <?php else: ?>
                <div class="alert alert-danger mg-top-15 text-left">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    No Exams available. Please create an exam by clicking <a href="<?php echo e(action('ExamController@create')); ?>">here</a>
                </div>
            <?php endif; ?>

        </div>
    </div><!-- .page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'layouts.master' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>