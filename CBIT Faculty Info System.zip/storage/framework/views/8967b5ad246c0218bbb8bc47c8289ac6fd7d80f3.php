<?php $__env->startSection( 'page-content' ); ?>
    <div class="page">
        <div class="page-main">

            <?php echo $__env->make('partials.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php if( ! empty( $subjects ) ): ?>
                <div class="page-header">
                    <h1 class="page-title">Lab Mark Types</h1>
                </div>

                <!-- .page-header -->
                <div class="page-content">

                    <div class="row">
                        <div class="col-lg-9">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">Select a course to add/remove mark types.</h4>
                                </div>
                                <?php echo e(Form::open( array('action' => 'LabMarkTypesController@create', 'method' => 'post',
                                    'class' => 'form-horizontal' ) )); ?>


                                <div class="panel-body admin-form">

                                    <div class="col-lg-8">
                                        <div class="section">
                                            <label for="select_subject" class="field-label">Select Course</label>
                                            <label for="select_subject" class="field">
                                                <?php echo e(Form::select('subject', $subjects, $subject_id ?? '' , [
                                                    'class' => 'form-control select',
                                                    'id' => 'select_subject' ])); ?>

                                            </label>
                                        </div>
                                    </div>

                                </div>
                                <div class="panel-footer admin-form" align="right">
                                    <input type="submit" class="btn btn-sm btn-primary" value="Get Mark Types">
                                </div>
                                <?php echo e(Form::close()); ?>

                            </div>
                        </div><!-- .col-lg-12 -->
                    </div><!-- .row -->

                    <?php if( ! empty( $labMarkTypes ) ): ?>

                        <div class="row">
                            <div class="col-lg-9">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">Lab Mark Types for <?php echo e($subject->name); ?></h4>
                                    </div>
                                    <?php echo e(Form::open(array('action' => 'LabMarkTypesController@store', 'method' => 'put'))); ?>

                                    <?php echo e(Form::hidden('subject', $subject_id)); ?>



                                    <div class="panel-body marks-table">
                                        <div class="table-responsive">
                                            <table class="table table-bordered mb-0 th-bb-n">
                                                <thead>
                                                <tr>
                                                    <th>Id</th>
                                                    <th>Name</th>
                                                    <th>Max Marks</th>
                                                    <th></th>
                                                </tr>
                                                </thead>
                                                <tbody id="lab-mark-types">
                                                <?php
                                                    $lmt_i = 1;
                                                ?>
                                                <?php $__currentLoopData = $labMarkTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $labMarkType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td class="width-50"><?php echo e($lmt_i); ?></td>
                                                        <td class="">
                                                            <?php echo e(Form::text( 'labMarkType[' . $lmt_i . '][]'  , $labMarkType->name,
                                                              array('class' => 'form-control'))); ?>

                                                        </td>
                                                        <td class="width-100">
                                                            <?php echo e(Form::number( 'labMarkType[' . $lmt_i . '][]'  , $labMarkType->max_marks,
                                                              array('class' => 'form-control'))); ?>

                                                        </td>
                                                        <td class="width-100">
                                                            <button class="btn btn-sm btn-default remove-mark-type">Remove</button>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                        $lmt_i++;
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="width-50"><?php echo e($lmt_i); ?></td>
                                                    <td class="">
                                                        <?php echo e(Form::text( 'labMarkType[' . $lmt_i . '][]'  , '',
                                                          array('class' => 'form-control'))); ?>

                                                    </td>
                                                    <td class="width-100">
                                                        <?php echo e(Form::number( 'labMarkType[' . $lmt_i . '][]'  , '',
                                                          array('class' => 'form-control'))); ?>

                                                    </td>
                                                    <td class="width-100">
                                                        <button class="btn btn-sm btn-default remove-mark-type">Remove</button>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div><!-- .table-responsive -->
                                    </div>
                                    <div class="" style="padding: 15px;">
                                        <button class="btn btn-sm btn-default add-mark-type">Add Mark Type</button>
                                    </div>
                                    <div class="panel-footer admin-form" align="right">
                                        <input type="submit" class="btn btn-sm btn-primary" value="Submit">
                                    </div>
                                    <?php echo e(Form::close()); ?>

                                </div>
                            </div><!-- .col-lg-12 -->
                        </div><!-- .row -->
                    <?php endif; ?>

                </div><!-- .page-content -->
            <?php endif; ?>

        </div>
    </div><!-- .page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'layouts.master' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>