<?php $__env->startSection( 'page-content' ); ?>
    <div class="page">
        <div class="page-main">

            <?php echo $__env->make('partials.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php if( ! empty( $exams ) ): ?>
                <div class="page-header">
                    <h1 class="page-title ">Mid Exam Marks</h1>
                </div>

                <!-- .page-header -->
                <div class="page-content">

                    <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title"><?php echo e($exam->name); ?> Marks</h4>
                                    </div>

                                    <div class="panel-body marks-table">
                                        <div class="table-responsive">
                                            <table class="table table-bordered mb-0 th-bb-n" id="student-lab-marks-entry">
                                                <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Subject</th>
                                                    <th>Marks of each question</th>
                                                    <th>Total Marks</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php
                                                    $questionPapers = $exam->questionPapers->whereIN('subject_id', $subject_ids);
                                                    $t1 = $t2 = 0;
                                                    $i = 1;
                                                ?>
                                                <?php $__currentLoopData = $questionPapers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questionPaper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $emarks = \App\ExamMark::getMarks( $student_id, $questionPaper->id );
                                                            $questions = $questionPaper->questions;
                                                        ?>
                                                        <tr>
                                                            <td class="width-50"><?php echo e($i++); ?></td>
                                                            <td><?php echo e($questionPaper->subject->name); ?></td>
                                                            <td>
                                                            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if( $question->subQuestions()->count() ): ?>
                                                                    <?php $__currentLoopData = $question->subQuestions()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $squestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <b><?php echo e($squestion->question); ?></b> : <?php echo e($emarks[ $question->id ][ $squestion->id ]); ?> / <?php echo e($squestion->max_marks); ?> &nbsp;
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php else: ?>
                                                                    <b><?php echo e($question->question); ?></b> : <?php echo e($emarks[ $question->id ]); ?> / <?php echo e($question->max_marks); ?> &nbsp;
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                            <td><?php echo e($emarks['total_marks']); ?> / <?php echo e($questionPaper->max_marks); ?> </td>
                                                            <?php $t1 += $emarks['total_marks'] ?>
                                                            <?php $t2 += $questionPaper->max_marks ?>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr><td colspan="3" style="text-align: right"><b>Total</b></td><td><b><?php echo e($t1); ?> / <?php echo e($t2); ?></b></td></tr>
                                                </tfoot>
                                            </table>
                                        </div><!-- .table-responsive -->
                                    </div>
                                </div>
                            </div><!-- .col-lg-12 -->
                        </div><!-- .row -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div><!-- .page-content -->
            <?php else: ?>
                <div class="alert alert-danger mg-top-15 text-left">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    No Exams available.
                </div>
            <?php endif; ?>

        </div>
    </div><!-- .page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'layouts.master' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>