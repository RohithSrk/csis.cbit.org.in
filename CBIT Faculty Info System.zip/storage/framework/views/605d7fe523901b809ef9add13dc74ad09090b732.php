<?php $__env->startSection( 'page-content' ); ?>
    <div class="page">
        <div class="page-main">
            <div class="page-header">
                <h1 class="page-title hidden"></h1>
            </div>

            <div class="page-content">
                <?php echo e($msg); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'layouts.master' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>