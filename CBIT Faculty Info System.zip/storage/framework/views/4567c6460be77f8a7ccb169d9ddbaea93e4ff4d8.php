<?php if( Session::has('success') ): ?>
    <div class="alert alert-success fade in alert-dismissable">
        <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
        <strong>Success!</strong> <?php echo e(Session::get('success')); ?>

        <?php echo e(Session::forget('success')); ?>

    </div>
<?php endif; ?>

<?php if( count( $errors->all() ) ): ?>
    <ul class="alert alert-danger mg-top-15 text-left">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li style="margin-left: 18px;"><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>