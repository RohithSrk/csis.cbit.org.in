<?php $__env->startSection( 'page-content' ); ?>
    <div class="page">
        <div class="page-main">

            <?php echo $__env->make('partials.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="page-header">
                <h1 class="page-title ">Add Consolidated Feedback</h1>
            </div><!-- .page-header -->

            <div class="page-content">

                <div class="row">
                    <div class="col-lg-9">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">Create Feedback Form</h4>
                            </div>
                            <?php echo e(Form::open(['action' => ['FeedbackDataController@create', $feedback->id], 'method' => 'post'])); ?>


                            <div class="panel-body admin-form">
                                <div class="col-md-3">
                                    <div class="section">
                                        <label for="select_semester" class="field-label">Select Semester</label>
                                        <label for="select_semester" class="field">
                                            <?php echo e(Form::select('semester', $semesters_arr, isset($semester_id)? $semester_id : '' , [
                                                'class' => 'form-control select',
                                                'id' => 'select_semester' ])); ?>

                                        </label>
                                    </div><!-- section -->
                                </div><!-- col-md-4 -->

                                <div class="col-md-3">
                                    <div class="section">
                                        <label for="select_section" class="field-label">Select Section</label>
                                        <label for="select_section" class="field">
                                            <?php echo e(Form::select('section',$sections_arr, isset($section_id)? $section_id : '' , [
                                                'class' => 'form-control select',
                                                'id' => 'select_section' ])); ?>

                                        </label>
                                    </div><!-- .section -->
                                </div><!-- .col-md-4 -->

                            </div><!-- .panel-body -->

                            <div class="panel-footer admin-form" align="right">
                                <input type="submit" class="btn btn-sm btn-primary" value="Get Form">
                            </div>
                            <?php echo e(Form::close()); ?>

                        </div>
                    </div><!-- .col-lg-12 -->
                </div><!-- .row -->

                <?php if( ! empty( $criteria )): ?>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                       <?php echo e($year->name); ?> <?php echo e($sections_arr[$section_id]); ?> Feedback.
                                    </h4>
                                </div>
                                <?php echo e(Form::open(array('action' => ['FeedbackDataController@store', $feedback->id], 'method' => 'put'))); ?>

                                <?php echo e(Form::hidden('section', $section_id)); ?>

                                <?php echo e(Form::hidden('semester', $semester_id)); ?>

                                <?php echo e(Form::hidden('feedback', $feedback->id)); ?>


                                <div class="panel-body marks-table">
                                    <div class="table-responsive">
                                        <table class="table table-bordered mb-0 th-bb-n">
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Subject</th>
                                                <th>Faculty</th>
                                                <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <th title="<?php echo e($criterion->code); ?>"><?php echo e($criterion->criterion); ?></th>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $i = 0 ?>
                                            <?php $__currentLoopData = $subjects_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject_id => $subject_name_code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $faculty_arr = \App\Subject::find( $subject_id )->getAssignedFacultyNames( $section_id );
                                                ?>
                                                <?php $__currentLoopData = $faculty_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty_id =>  $faculty_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td class="width-50"><?php echo e(++$i); ?></td>
                                                        <td><?php echo e($subject_name_code); ?></td>
                                                        <td><?php echo e($faculty_name); ?></td>
                                                        <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <td class="width-100"><?php echo e(Form::number( 'feedback_data[' . $subject_id . ']['. $faculty_id .' ][' . $criterion->code . ']' , '',
                                                           array('min' => 0, 'max' => 4, 'class' => 'form-control', 'title' => $criterion->criterion, 'required' ))); ?></td>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div><!-- .table-responsive -->
                                </div>
                                <div class="panel-footer admin-form" align="right">
                                    <input type="submit" class="btn btn-sm btn-primary" value="Submit Feedback">
                                </div>
                                <?php echo e(Form::close()); ?>

                            </div>
                        </div><!-- .col-lg-12 -->
                    </div><!-- .row -->
                <?php endif; ?>

            </div><!-- .page-content -->


        </div>
    </div><!-- .page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'layouts.master' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>