<?php $__env->startSection( 'page-content' ); ?>
    <div class="page">
        <div class="page-main">

            <?php echo $__env->make('partials.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php if( ! empty( $subjects ) ): ?>
                <div class="page-header">
                    <h1 class="page-title ">Lab Marks Report</h1>
                </div>

                <!-- .page-header -->
                <div class="page-content">

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">Select Students</h4>
                                </div>
                                <?php echo e(Form::open(array('action' => 'LabMarksController@viewLabMarks', 'method' => 'post'))); ?>


                                    <div class="panel-body admin-form">

                                        <div class="col-md-8">
                                            <div class="section">
                                                <label for="select_subject" class="field-label">Select Course</label>
                                                <label for="select_subject" class="field">
                                                    <?php echo e(Form::select('subject', $subjects, $subject_id ?? '' , [
                                                        'class' => 'form-control select',
                                                        'id' => 'select_subject' ])); ?>

                                                </label>
                                            </div>
                                        </div>

                                        <div class="col-md-2">
                                            <div class="section">
                                                <label for="select_section" class="field-label">Select Section</label>
                                                <label for="select_section" class="field">
                                                    <?php echo e(Form::select('section',$sections, $section_id ?? '' , [
                                                        'class' => 'form-control select',
                                                        'id' => 'select_section' ])); ?>

                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="section">
                                                <label for="select_batch" class="field-label">Select Batch</label>
                                                <label for="select_batch" class="field">
                                                    <?php echo e(Form::select('batch',$batches, $batch_id ?? '' , [
                                                        'class' => 'form-control select',
                                                        'id' => 'select_batch' ])); ?>

                                                </label>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="panel-footer admin-form" align="right">
                                        <input type="submit" class="btn btn-sm btn-primary" value="Get Students">
                                    </div>
                                <?php echo e(Form::close()); ?>

                            </div>
                        </div><!-- .col-lg-12 -->
                    </div><!-- .row -->

                    <?php if( ! empty( $students ) ): ?>

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">Average Student Lab Marks</h4>
                                    </div>

                                    <div class="panel-body marks-table">
                                        <div class="table-responsive">
                                            <table class="table table-bordered mb-0 th-bb-n">
                                                <thead>
                                                <tr>
                                                    <th>Roll Number</th>
                                                    <th>Name</th>
                                                    <?php $__currentLoopData = $mark_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <th><?php echo e($mark_type['name']); ?></th>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <th>Total</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td class="width-150"><?php echo e($student->rollnum); ?></td>
                                                        <td><?php echo e($student->name); ?></td>

                                                        <?php
                                                            $stdAvgLabMarks = $student->getAvgLabMarks( $subject_id );
                                                        ?>

                                                        <?php $__currentLoopData = $mark_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <td class="width-100">
                                                                <?php echo e($stdAvgLabMarks[$mark_type['name']]); ?>

                                                            </td>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <td class="width-100">
                                                            <?php echo e($stdAvgLabMarks['Total']); ?>

                                                        </td>

                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div><!-- .table-responsive -->
                                    </div>
                                </div>
                            </div><!-- .col-lg-12 -->
                        </div><!-- .row -->
                    <?php endif; ?>

                </div><!-- .page-content -->
            <?php endif; ?>
        </div>
    </div><!-- .page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'layouts.master' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>