<?php $__env->startSection('content'); ?>

    <div class="site-wrap feedback-dashboard" >

        <div class="page" style="background-color: white">
            <div class="page-main">

                <?php echo $__env->make('partials.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php if( ! empty( $feedback_users ) ): ?>

                    <div class="page-header text-center">
                        <h1 class="page-title"><?php echo e($year->name); ?> <?php echo e($section->name); ?> Feedback Users</h1>
                    </div>

                    <div class="page-content">

                        <div class="row">
                            <div class="col-lg-8 col-lg-push-2">

                                <?php $__currentLoopData = $feedback_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="col-md-4 col-print-4 mb-25">
                                    <table class="table table-bordered mb-0 th-bb-n">
                                        <tr>
                                            <th style="text-align:  center"><?php echo e($feedback_user->student); ?></th>
                                        </tr>
                                        <tr>
                                            <td style="text-align:  center">Username: <?php echo e($feedback_user->username); ?></td>
                                        </tr>
                                        <tr>
                                            <td style="text-align:  center">Password: <?php echo e($feedback_user->plain_password); ?></td>
                                        </tr>
                                    </table>
                                </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div><!-- .col-lg-12 -->
                        </div><!-- .row -->
                    </div>

                <?php endif; ?>
            </div>
        </div>

    </div>

    <?php echo $__env->make('partials.js-data', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>