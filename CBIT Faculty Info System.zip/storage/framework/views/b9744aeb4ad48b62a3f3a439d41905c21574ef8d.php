<?php $__env->startSection('content'); ?>
    <div class="site-wrap login">
        <div id="reset-password-form">
            <div class="col-md-4" align="center">
                <div class="panel panel-default">
                    <div class="panel-header">
                        <div class="logo">
                            <h2>Reset Password</h2>
                        </div>
                    </div>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo e(csrf_field()); ?>


                    <div class="panel-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?> form-group-email">
                            <label for="email" hidden class="col-md-4 control-label">E-Mail Address</label>

                            <div class="">
                                <input id="email" type="email" placeholder="E-Mail Address" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div><!-- .panel-body -->
                    <div class="panel-footer" align="right">
                        <input type="submit" class="btn btn-primary" value="Send Password Reset Link">
                    </div><!-- .panel-footer -->
                </form>
            </div><!-- .panel -->
        </div><!-- .col-md-4 -->
    </div><!-- #login-form -->
    </div><!-- .site-wrap -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>