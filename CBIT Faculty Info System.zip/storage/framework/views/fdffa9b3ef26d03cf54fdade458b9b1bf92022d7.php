<?php $__env->startSection('content'); ?>
    <div class="site-wrap login">
        <div id="login-form">
            <div class="col-md-4" align="center">
                <div class="panel panel-default">
                    <div class="panel-header">
                        <div class="logo">
                            <h2>Login</h2>
                        </div>
                    </div>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="panel-body" align="left">
                            <p class="mg-btm-15">Enter your email / Id and password to login</p>

                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?> form-group-email">
                                <label for="email" class="col-md-4 hidden control-label">E-Mail Address or Id</label>

                                <div class="col-md-6-">
                                    <input id="email" type="text" class="form-control" name="email" placeholder="Email or Id" value="<?php echo e(old('email')); ?>" required autofocus>

                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?> form-group-password">
                                <label for="password" class="col-md-4 hidden control-label">Password</label>

                                <div class="col-md-6-">
                                    <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>

                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="checkbox inline-block mg-top-10">
                                <label>
                                    <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Keep Me Signed In
                                </label>
                            </div>

                            <div class="pull-right mg-top-10">
                                <a href="<?php echo e(route('password.request')); ?>">Forgot Password?</a>
                            </div>
                        </div><!-- .panel-body -->
                        <div class="panel-footer" align="right">
                            <input type="submit" class="btn btn-primary" value="Login">
                        </div><!-- .panel-footer -->
                    </form>
                </div><!-- .panel -->
            </div><!-- .col-md-4 -->
        </div><!-- #login-form -->
    </div><!-- .site-wrap -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>