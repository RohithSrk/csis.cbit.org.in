<?php $__env->startSection( 'page-content' ); ?>
    <div class="page">
        <div class="page-main">

            <?php echo $__env->make('partials.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="page-header">
                <h1 class="page-title ">Dummy Feedback Users</h1>
            </div><!-- .page-header -->

            <div class="page-content">

                <div class="row">
                    <div class="col-lg-9">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">Get Feedback Users</h4>
                            </div>
                            <?php echo e(Form::open(['action' => ['FeedbackDataController@listFeedbackUsers', $feedback->id], 'method' => 'post'])); ?>


                            <div class="panel-body admin-form">
                                <div class="col-md-3">
                                    <div class="section">
                                        <label for="select_semester" class="field-label">Select Semester</label>
                                        <label for="select_semester" class="field">
                                            <?php echo e(Form::select('semester', $semesters_arr, isset($semester_id)? $semester_id : '' , [
                                                'class' => 'form-control select',
                                                'id' => 'select_semester' ])); ?>

                                        </label>
                                    </div><!-- section -->
                                </div><!-- col-md-4 -->

                                <div class="col-md-3">
                                    <div class="section">
                                        <label for="select_section" class="field-label">Select Section</label>
                                        <label for="select_section" class="field">
                                            <?php echo e(Form::select('section',$sections_arr, isset($section_id)? $section_id : '' , [
                                                'class' => 'form-control select',
                                                'id' => 'select_section' ])); ?>

                                        </label>
                                    </div><!-- .section -->
                                </div><!-- .col-md-4 -->

                            </div><!-- .panel-body -->

                            <div class="panel-footer admin-form" align="right">
                                <input type="submit" class="btn btn-sm btn-primary" value="Get Users">
                            </div>
                            <?php echo e(Form::close()); ?>

                        </div>
                    </div><!-- .col-lg-12 -->
                </div><!-- .row -->

                <?php if( ! empty( $feedback_users )): ?>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading clearfix">
                                    <h4 class="panel-title left">
                                       <?php echo e($year->name); ?> <?php echo e($sections_arr[$section_id]); ?> Feedback.
                                    </h4>
                                    <a href="/feedback-new/<?php echo e($feedback->id); ?>/<?php echo e($section_id); ?>/print-users" target="_blank" class="btn btn-sm btn-primary right">Print users</a>
                                </div>
                                <?php echo e(Form::open(array('action' => ['FeedbackDataController@store', $feedback->id], 'method' => 'put'))); ?>

                                <?php echo e(Form::hidden('section', $section_id)); ?>

                                <?php echo e(Form::hidden('semester', $semester_id)); ?>

                                <?php echo e(Form::hidden('feedback', $feedback->id)); ?>


                                <div class="panel-body marks-table">
                                    <div class="table-responsive">
                                        <table class="table table-bordered mb-0 th-bb-n">
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Username</th>
                                                <th>Password</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $i = 0 ?>
                                            <?php $__currentLoopData = $feedback_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="width-50"><?php echo e(++$i); ?></td>
                                                    <td><?php echo e($feedback_user->username); ?></td>
                                                    <td><?php echo e($feedback_user->plain_password); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div><!-- .table-responsive -->
                                </div>
                                <div class="panel-footer admin-form" align="right">
                                    <input type="submit" class="btn btn-sm btn-primary" value="Submit Feedback">
                                </div>
                                <?php echo e(Form::close()); ?>

                            </div>
                        </div><!-- .col-lg-12 -->
                    </div><!-- .row -->
                <?php endif; ?>

            </div><!-- .page-content -->


        </div>
    </div><!-- .page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'layouts.master' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>