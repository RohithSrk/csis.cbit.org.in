<?php $__env->startSection( 'page-content' ); ?>
    <div class="page">
        <div class="page-main">

            <?php echo $__env->make('partials.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php if( $feedback_items->count() ): ?>
                <div class="page-header">
                    <h1 class="page-title ">Add Feedback</h1>
                </div>

                <!-- .page-header -->
                <div class="page-content">

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">List of all available feedback</h4>
                                </div>

                                <div class="panel-body marks-table">
                                    <div class="table-responsive">
                                        <table class="table table-bordered mb-0 th-bb-n">
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th colspan="4">Actions</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $i = 0 ?>
                                            <?php $__currentLoopData = $feedback_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="width-50"><?php echo e(++$i); ?></td>
                                                    <td ><?php echo e($feedback_item->name); ?></td>
                                                    <?php if( $feedback_item->feedback_type == 'new' ): ?>
                                                        <td class="width-100"><a href="/feedback-new-data/<?php echo e($feedback_item->id); ?>/get" class="btn btn-sm btn-default">Get Users</a></td>
                                                        <td class="width-100" colspan="2"><a href="/feedback/<?php echo e($feedback_item->id); ?>/edit" class="btn btn-sm btn-default">Edit Name/Dates</a></td>
                                                    <?php else: ?>
                                                        <td class="width-100"><a href="/feedback-data/<?php echo e($feedback_item->id); ?>/add" class="btn btn-sm btn-default">Add Data</a></td>
                                                        <td class="width-100"><a href="/feedback/<?php echo e($feedback_item->id); ?>/edit" class="btn btn-sm btn-default">Edit Name/Dates</a></td>
                                                    <?php endif; ?>

                                                    <?php if( $feedback_item->feedback_type != 'new' ): ?>
                                                        <td class="width-100"><a href="/feedback-data/<?php echo e($feedback_item->id); ?>/edit" class="btn btn-sm btn-default">Edit Data</a></td>
                                                    <?php endif; ?>
                                                    <td class="width-100"><a href="/feedback/<?php echo e($feedback_item->id); ?>/delete" class="btn btn-sm btn-default">Delete</a></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div><!-- .table-responsive -->
                                </div><!-- .panel-body -->
                            </div><!-- .panel -->
                        </div><!-- .col-lg-12 -->
                    </div><!-- .row -->

                </div><!-- .page-content -->
            <?php else: ?>
                <div class="alert alert-danger mg-top-15 text-left">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    No feedback available. Please create a new feedback by clicking <a href="<?php echo e(action('FeedbackController@create')); ?>">here</a>
                </div>
            <?php endif; ?>

        </div>
    </div><!-- .page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'layouts.master' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>