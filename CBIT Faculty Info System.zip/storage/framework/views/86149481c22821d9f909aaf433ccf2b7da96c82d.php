<aside id="sidebar">

    <ul class="nav">
        <li class="menu-item <?php echo e(empty( request()->segment(1) )? 'active' : ''); ?>">
            <a href="/"><i class="fa fa-home"></i><span class="menu-title">Home</span></a>
        </li>
        <?php if(auth()->user()->hasAnyRole(['HOD', 'Principal'])): ?>
            <li class="menu-item <?php echo e((request()->segment(3) == 'assign-courses' )? 'active' : ''); ?>">
                <a href="<?php echo e(action('CoursesController@index')); ?>"><i class="fa fa-link"></i><span class="menu-title">Assign Courses</span></a>
            </li>
        <?php endif; ?>
        <li class="menu-item <?php echo e((request()->segment(2) == 'add-lab-marks') ? 'active' : ''); ?>">
            <a href="<?php echo e(action('LabMarksController@index')); ?>"><i class="fa fa-list"></i><span class="menu-title">Add/Edit Lab Marks</span></a>
        </li>
        <li class="menu-item <?php echo e((request()->segment(2) == 'add-absentee-lab-marks') ? 'active' : ''); ?>">
            <a href="<?php echo e(action('AbsenteeLabMarksController@index')); ?>"><i class="fa fa-list"></i><span class="menu-title">Add Marks for Absentee</span></a>
        </li>
        <li class="menu-item <?php echo e((request()->segment(2) == 'view-lab-marks') ? 'active' : ''); ?>">
            <a href="<?php echo e(action('LabMarksController@indexLabMarks')); ?>"><i class="fa fa-list-alt"></i><span class="menu-title">View Lab Marks</span></a>
        </li>
        <li class="menu-item <?php echo e((request()->segment(2) == 'manage-mark-types') ? 'active' : ''); ?>">
            <a href="<?php echo e(action('LabMarkTypesController@index')); ?>"><i class="fa fa-columns"></i><span class="menu-title">Labmark Division</span></a>
        </li>
        <li class="menu-item hidden">
            <a href="#"><i class="fa fa-calendar-o"></i><span class="menu-title">Events</span></a>
        </li>
        <li class="menu-item">
            <a href="#"><i class="fa fa-calendar-o"></i><span class="menu-title">Add/Update Event</span></a>
        </li>
        <li class="menu-item hidden">
            <a href="#"><i class="fa fa-file-excel-o"></i><span class="menu-title">Add/Edit Mid Marks</span></a>
        </li>
        <li class="menu-item hidden">
            <a href="#"><i class="fa fa-pie-chart"></i><span class="menu-title">View Mid Marks</span></a>
        </li>
        <li class="menu-item hidden">
            <a href="<?php echo e(URL::to('logout')); ?>"><i class="fa fa-sign-out"></i><span class="menu-title">Logout</span></a>
        </li>
        <li class="menu-item">
            <a href="#"><i class="fa fa-info-circle"></i><span class="menu-title">About</span></a>
        </li>
    </ul>

</aside><!-- #sidebar -->