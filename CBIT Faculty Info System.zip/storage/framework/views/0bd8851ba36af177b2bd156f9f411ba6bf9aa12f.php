<table class="subcopy" width="100%" cellpadding="0" cellspacing="0">
    <tr>
        <td>
            <?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

        </td>
    </tr>
</table>
