<?php $__env->startSection( 'page-content' ); ?>
    <div class="page">
        <div class="page-main">

            <?php echo $__env->make('partials.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="page-header">
                <h1 class="page-title ">Assign Faculty for Courses</h1>
            </div>

            <!-- .page-header -->
            <div class="page-content">

                <div class="row">
                    <div class="col-lg-9">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">Select Courses</h4>
                            </div>
                            <?php echo e(Form::open( array( 'action' => 'CoursesController@create',
                               'method' => 'post', 'class' => 'form-horizontal' ) )); ?>


                                <div class="panel-body admin-form">
                                    <div class="col-md-4">
                                        <div class="section">
                                            <label for="select_semester" class="field-label">Select Semester</label>
                                            <label for="select_semester" class="field">
                                                <?php echo e(Form::select('semester', $semesters_arr, $semester_id ?? '' , [
                                                    'class' => 'form-control select',
                                                    'id' => 'select_semester' ])); ?>

                                            </label>
                                        </div><!-- section -->
                                    </div><!-- col-md-4 -->

                                    <div class="col-lg-4">
                                        <div class="section">
                                            <label for="select_section" class="field-label">Select Section</label>
                                            <label for="select_section" class="field">
                                                <?php echo e(Form::select('section',$sections_arr, $section_id ?? '' , [
                                                    'class' => 'form-control select',
                                                    'id' => 'select_section' ])); ?>

                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-footer admin-form" align="right">
                                    <input type="submit" class="btn btn-sm btn-primary" value="Get Courses">
                                </div>
                            <?php echo e(Form::close()); ?>

                        </div>
                    </div><!-- .col-lg-12 -->
                </div><!-- .row -->

                <?php if( ! empty( $subjects ) ): ?>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">Assign Faculty for courses of <?php echo e($semesters_arr[$semester_id] . ' ' . $sections_arr[$section_id]); ?></h4>
                                </div>
                                <?php echo e(Form::open( [ 'action' => 'CoursesController@store', 'method' => 'put' ]  )); ?>

                                <?php echo e(Form::hidden('semester', $semester_id)); ?>

                                <?php echo e(Form::hidden('section', $section_id)); ?>


                                    <div class="panel-body marks-table">
                                        <div class="">
                                            <table class="table table-bordered mb-0 th-bb-n">
                                                <thead>
                                                <tr>
                                                    <th>Sid</th>
                                                    <th>Name</th>
                                                    <th>Faculty</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td class="width-50"><?php echo e($subject->id); ?></td>
                                                        <td><?php echo e($subject->getNameWithCode()); ?></td>

                                                        <td class="width-250">
                                                            <?php echo e(Form::select( 'subjects['. $subject->code . '][]',
                                                              $faculty_arr, $subject->getAssignedFaculty( $section_id ),
                                                              array( 'id' => '', 'class' => 'course-selector form-control',
                                                              'multiple' => 'multiple'))); ?>

                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div><!-- .table-responsive -->
                                    </div>
                                    <div class="panel-footer admin-form" align="right">
                                        <input type="submit" class="btn btn-sm btn-primary" value="Submit">
                                    </div>
                                <?php echo e(Form::close()); ?>

                            </div>
                        </div><!-- .col-lg-12 -->
                    </div><!-- .row -->
                <?php endif; ?>

            </div>
            <!-- .page-content -->
        </div>
    </div>
    <!-- .page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'layouts.master' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>