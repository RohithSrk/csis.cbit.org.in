<?php $__env->startSection('content'); ?>

    <div class="site-wrap feedback-dashboard dashboard">

        <?php echo $__env->make( 'partials.feedback-navbar' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="page">
            <div class="page-main">

                <?php echo $__env->make('partials.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php if( ! empty( $criteria ) ): ?>

                <div class="page-header">
                    <h1 class="page-title hidden"></h1>
                </div>

                <div class="page-content">

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <?php echo e($year->name); ?> <?php echo e($section->name); ?> Feedback
                                    </h4>
                                </div>

                                <?php echo e(Form::open( ['action' => 'FeedbackUserController@store', 'method' => 'post' ] )); ?>

                                <?php echo e(Form::hidden('feedback', $feedback->id)); ?>

                                <?php echo e(Form::hidden('section', $section->id)); ?>


                                <div class="panel-body marks-table">
                                    <div class="table-responsive">
                                        <table class="table table-bordered mb-0 th-bb-n">
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Subject</th>
                                                <th>Faculty</th>
                                                <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <th title="<?php echo e($criterion->code); ?>"><?php echo e($criterion->criterion); ?></th>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $i = 0 ?>
                                            <?php $__currentLoopData = $subjects_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject_id => $subject_name_code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $faculty_arr = \App\Subject::find( $subject_id )->getAssignedFacultyNames( $section->id );
                                                ?>
                                                <?php $__currentLoopData = $faculty_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty_id =>  $faculty_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td class="width-50"><?php echo e(++$i); ?></td>
                                                        <td><?php echo e($subject_name_code); ?></td>
                                                        <td><?php echo e($faculty_name); ?></td>
                                                        <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <td class="width-100"><?php echo e(Form::number( 'feedback_data[' . $subject_id . ']['. $faculty_id .' ][' . $criterion->code . ']' , '',
                                                           array('min' => 0, 'max' => 4, 'class' => 'form-control', 'title' => $criterion->criterion ))); ?></td>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div><!-- .table-responsive -->
                                </div>
                                <div class="panel-footer admin-form" align="right">
                                    <input type="submit" class="btn btn-sm btn-primary" value="Submit Feedback">
                                </div>
                                <?php echo e(Form::close()); ?>

                            </div>
                        </div><!-- .col-lg-12 -->
                    </div><!-- .row -->
                </div>

                <?php endif; ?>
            </div>
        </div>

        <?php echo $__env->make( 'partials.footer' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>

    <?php echo $__env->make('partials.js-data', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>