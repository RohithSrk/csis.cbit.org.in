<footer id="site-footer" class="clearfix">
    <div class="site-footer-right">
        Crafted with <i class="fa fa-heart"></i> by
        <a href="https://twitter.com/SrkRohith" target="_blank">@SrkRohith</a>,
        <a href="https://twitter.com/ramlmn" target="_blank">@ramlmn</a>,
        <a href="https://twitter.com/harshatech" target="_blank">@harshatech</a>
    </div>
    <div class="site-footer-legal">© {{ date( 'Y' ) }} <a href="https://cbitosc.github.io/" target="_blank">COSC</a></div>
</footer><!-- .site-footer -->